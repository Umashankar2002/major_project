document.getElementById('registrationForm').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission

    // Add your logic here to handle the registration form data
    // You can use AJAX to send the data to the server for processing

    // For now, let's just log the form data to the console
    console.log('Form submitted!');
    console.log('Name:', document.getElementById('name').value);
    console.log('Password:', document.getElementById('password').value);
    console.log('Phone Number:', document.getElementById('phoneNumber').value);
    console.log('Email:', document.getElementById('email').value);
});
